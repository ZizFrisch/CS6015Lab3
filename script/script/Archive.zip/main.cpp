//
//  main.cpp
//  HW1 CS 6015
//
//  Created by Elisabeth Frischknecht on 1/11/24.
//

#include <iostream>
#include "cmdline.hpp"
#include <string>

int main(int argc, const char * argv[]) {
    
    use_arguments(argc, argv);

    return 0;
}
