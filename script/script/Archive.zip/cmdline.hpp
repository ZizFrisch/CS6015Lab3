//
//  cmdline.hpp
//  HW1 CS6015
//
//  Created by Elisabeth Frischknecht on 1/11/24.
//

#pragma once
#ifndef cmdline_hpp
#define cmdline_hpp

#include <stdio.h>

void use_arguments(int argc, const char * argv[]);

#endif /* cmdline_hpp */
